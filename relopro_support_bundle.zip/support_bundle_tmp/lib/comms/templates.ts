// ENHANCEMENT_comms_hub: Placeholder for communication templates
// This file is part of the Comms Hub feature manifest.

export const commsTemplates = {
    // Future templates can be added here
};
